import './App.css'
import {ToDo} from "./components/ToDo"

function App() {
  // const [msg, setMsg] = useState(0)

  return (

    <div className="App">
      <ToDo />
    </div>
  )
}

export default App

